package com.bytebyte.hanko

import android.net.Uri
import android.os.Bundle
import android.widget.Toast
import android.widget.VideoView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.media3.common.util.UnstableApi

@UnstableApi
class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { HankoApp() }
    }
}

@UnstableApi
@Composable
fun HankoApp(vm: MainVm = viewModel()) {
    var settings by remember { mutableStateOf(false) }
    GlassBackground {
        Column(
            Modifier.fillMaxSize().systemBarsPadding().verticalScroll(rememberScrollState()).padding(20.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("判子", fontSize = 44.sp, fontWeight = FontWeight.Bold, color = Red)
                    Text("Hanko, vídeos cortos con IA", color = Ink.copy(alpha = .7f))
                }
                Pill(if (settings) "Cerrar" else "Ajustes", filled = false) { settings = !settings }
            }
            if (settings) SettingsCard(vm.prefs) else HomeCard(vm)
        }
    }
}

@UnstableApi
@Composable
fun HomeCard(vm: MainVm) {
    val ctx = LocalContext.current
    var topic by remember { mutableStateOf("") }
    var lang by remember { mutableStateOf("es") }
    Glass(Modifier.fillMaxWidth()) {
        Text("¿Sobre qué quieres el vídeo?", fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(10.dp))
        GlassField(topic, { topic = it }, "Curiosidades de Japón")
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            listOf("es" to "Español", "en" to "English", "ja" to "日本語").forEach { (c, n) ->
                Pill(n, filled = lang == c) { lang = c }
            }
        }
        Spacer(Modifier.height(16.dp))
        Pill(if (vm.busy) "Creando…" else "Generar vídeo", filled = true, modifier = Modifier.fillMaxWidth()) {
            if (!vm.busy && topic.isNotBlank()) vm.generate(topic.trim(), lang)
        }
    }
    if (vm.busy) Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CircularProgressIndicator(color = Red, modifier = Modifier.size(22.dp), strokeWidth = 2.dp)
            Spacer(Modifier.width(12.dp))
            Text(vm.status, color = Ink)
        }
    }
    vm.errorMsg?.let { Glass(Modifier.fillMaxWidth()) { Text(it, color = Red) } }
    vm.result?.let { f ->
        Glass(Modifier.fillMaxWidth()) {
            key(f.path, f.lastModified()) {
                AndroidView(
                    factory = { c ->
                        VideoView(c).apply {
                            setVideoURI(Uri.fromFile(f))
                            setOnPreparedListener { it.isLooping = true; start() }
                        }
                    },
                    modifier = Modifier.fillMaxWidth().aspectRatio(9f / 16f).clip(RoundedCornerShape(20.dp))
                )
            }
            Spacer(Modifier.height(14.dp))
            Pill("Guardar en galería", filled = true, modifier = Modifier.fillMaxWidth()) {
                vm.save()
                Toast.makeText(ctx, "Guardado en Películas/Hanko", Toast.LENGTH_SHORT).show()
            }
        }
    }
}

@Composable
fun SettingsCard(p: Prefs) {
    var url by remember { mutableStateOf(p.llmUrl) }
    var key by remember { mutableStateOf(p.llmKey) }
    var model by remember { mutableStateOf(p.llmModel) }
    var pex by remember { mutableStateOf(p.pexelsKey) }
    Glass(Modifier.fillMaxWidth()) {
        Text("IA de texto (compatible con OpenAI)", fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(8.dp))
        GlassField(url, { url = it; p.llmUrl = it }, "URL base")
        Spacer(Modifier.height(8.dp))
        GlassField(key, { key = it; p.llmKey = it }, "Clave API", secret = true)
        Spacer(Modifier.height(8.dp))
        GlassField(model, { model = it; p.llmModel = it }, "Modelo")
        Spacer(Modifier.height(18.dp))
        Text("Clips de vídeo", fontWeight = FontWeight.SemiBold, color = Ink)
        Spacer(Modifier.height(8.dp))
        GlassField(pex, { pex = it; p.pexelsKey = it }, "Clave de Pexels", secret = true)
        Spacer(Modifier.height(14.dp))
        Text(
            "Las claves se guardan solo en tu móvil. Los vídeos son de Pexels: respeta su licencia.",
            color = Ink.copy(alpha = .6f), fontSize = 13.sp
        )
    }
}
