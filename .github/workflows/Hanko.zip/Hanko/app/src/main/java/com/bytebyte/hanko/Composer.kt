package com.bytebyte.hanko

import android.content.ContentValues
import android.content.Context
import android.graphics.Typeface
import android.net.Uri
import android.os.Environment
import android.provider.MediaStore
import android.text.SpannableString
import android.text.style.AbsoluteSizeSpan
import android.text.style.BackgroundColorSpan
import android.text.style.ForegroundColorSpan
import android.text.style.StyleSpan
import androidx.media3.common.Effect
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.util.UnstableApi
import androidx.media3.effect.OverlayEffect
import androidx.media3.effect.OverlaySettings
import androidx.media3.effect.Presentation
import androidx.media3.effect.TextOverlay
import androidx.media3.effect.TextureOverlay
import androidx.media3.transformer.Composition
import androidx.media3.transformer.EditedMediaItem
import androidx.media3.transformer.EditedMediaItemSequence
import androidx.media3.transformer.Effects
import androidx.media3.transformer.ExportException
import androidx.media3.transformer.ExportResult
import androidx.media3.transformer.Transformer
import com.google.common.collect.ImmutableList
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import java.io.File
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

@UnstableApi
object Composer {
    private fun wrap(t: String, max: Int = 24): String {
        if (!t.contains(' ')) return t.chunked(12).joinToString("\n")
        val sb = StringBuilder(); var line = 0
        for (w in t.split(" ")) {
            if (line > 0 && line + w.length > max) { sb.append('\n'); line = 0 }
            else if (line > 0) { sb.append(' '); line++ }
            sb.append(w); line += w.length
        }
        return sb.toString()
    }

    private fun subtitle(text: String): TextureOverlay {
        val s = SpannableString(wrap(text))
        s.setSpan(ForegroundColorSpan(android.graphics.Color.WHITE), 0, s.length, 0)
        s.setSpan(AbsoluteSizeSpan(64), 0, s.length, 0)
        s.setSpan(StyleSpan(Typeface.BOLD), 0, s.length, 0)
        s.setSpan(BackgroundColorSpan(0xCCC8102E.toInt()), 0, s.length, 0) // rojo Hanko
        return TextOverlay.createStaticTextOverlay(
            s, OverlaySettings.Builder().setBackgroundFrameAnchor(0f, -0.55f).build()
        )
    }

    /** Une clips verticales 1080x1920 + subtítulos + voz. Cada clip dura lo que su frase. */
    suspend fun render(
        ctx: Context, scenes: List<Scene>, voices: List<File>, voiceMs: List<Long>,
        clips: List<File>, clipSec: List<Double>, out: File
    ) = withContext(Dispatchers.Main) {
        if (out.exists()) out.delete()
        val video = scenes.indices.map { i ->
            val ms = minOf(voiceMs[i], (clipSec[i] * 1000).toLong() - 100)
            val media = MediaItem.Builder().setUri(Uri.fromFile(clips[i]))
                .setClippingConfiguration(
                    MediaItem.ClippingConfiguration.Builder().setEndPositionMs(ms).build()
                ).build()
            val fx = listOf<Effect>(
                Presentation.createForWidthAndHeight(1080, 1920, Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP),
                OverlayEffect(ImmutableList.of(subtitle(scenes[i].text)))
            )
            EditedMediaItem.Builder(media).setRemoveAudio(true).setEffects(Effects(emptyList(), fx)).build()
        }
        val audio = voices.map { EditedMediaItem.Builder(MediaItem.fromUri(Uri.fromFile(it))).build() }
        val composition = Composition.Builder(
            listOf(EditedMediaItemSequence(video), EditedMediaItemSequence(audio))
        ).build()

        suspendCancellableCoroutine<Unit> { c ->
            val t = Transformer.Builder(ctx)
                .setVideoMimeType(MimeTypes.VIDEO_H264)
                .setAudioMimeType(MimeTypes.AUDIO_AAC)
                .addListener(object : Transformer.Listener {
                    override fun onCompleted(composition: Composition, exportResult: ExportResult) { c.resume(Unit) }
                    override fun onError(composition: Composition, exportResult: ExportResult, exportException: ExportException) {
                        c.resumeWithException(exportException)
                    }
                }).build()
            t.start(composition, out.absolutePath)
            c.invokeOnCancellation { t.cancel() }
        }
    }

    fun saveToGallery(ctx: Context, f: File) {
        val v = ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, "hanko_${System.currentTimeMillis()}.mp4")
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_MOVIES + "/Hanko")
        }
        val uri = ctx.contentResolver.insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v)!!
        ctx.contentResolver.openOutputStream(uri)!!.use { o -> f.inputStream().use { it.copyTo(o) } }
    }
}
