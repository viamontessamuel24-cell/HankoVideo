package com.bytebyte.hanko

import android.content.Context

class Prefs(ctx: Context) {
    private val sp = ctx.getSharedPreferences("hanko", Context.MODE_PRIVATE)
    private fun get(k: String, d: String) = sp.getString(k, d) ?: d
    private fun put(k: String, v: String) = sp.edit().putString(k, v).apply()

    var llmUrl: String get() = get("llmUrl", "https://api.openai.com/v1"); set(v) = put("llmUrl", v)
    var llmKey: String get() = get("llmKey", ""); set(v) = put("llmKey", v)
    var llmModel: String get() = get("llmModel", "gpt-4o-mini"); set(v) = put("llmModel", v)
    var pexelsKey: String get() = get("pexelsKey", ""); set(v) = put("pexelsKey", v)
}
