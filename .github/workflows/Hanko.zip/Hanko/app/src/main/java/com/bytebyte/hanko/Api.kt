package com.bytebyte.hanko

import android.media.MediaMetadataRetriever
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Scene(val text: String, val search: String)

object Api {
    private val http = OkHttpClient.Builder().callTimeout(120, TimeUnit.SECONDS).build()

    private fun langName(c: String) = when (c) { "en" -> "English"; "ja" -> "Japanese"; else -> "Spanish" }

    /** Paso 1: guion con cualquier API compatible con OpenAI (OpenAI, DeepSeek, Gemini...). */
    fun script(p: Prefs, topic: String, lang: String): List<Scene> {
        val prompt = "Write a short vertical video script about: $topic. Language: ${langName(lang)}. " +
            "6 to 8 scenes, each one a single short sentence (max 18 words). For each scene add an English " +
            "stock-footage search term of 2-3 words. Reply ONLY with JSON: " +
            "{\"scenes\":[{\"text\":\"...\",\"search\":\"...\"}]}"
        val body = JSONObject()
            .put("model", p.llmModel)
            .put("messages", JSONArray().put(JSONObject().put("role", "user").put("content", prompt)))
            .toString()
        val req = Request.Builder()
            .url(p.llmUrl.trimEnd('/') + "/chat/completions")
            .header("Authorization", "Bearer ${p.llmKey}")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()
        http.newCall(req).execute().use { r ->
            val s = r.body!!.string()
            if (!r.isSuccessful) throw IllegalStateException("IA de texto ${r.code}: ${s.take(160)}")
            val txt = JSONObject(s).getJSONArray("choices").getJSONObject(0)
                .getJSONObject("message").getString("content")
            val arr = JSONObject(txt.substring(txt.indexOf('{'), txt.lastIndexOf('}') + 1)).getJSONArray("scenes")
            return (0 until arr.length()).map {
                val o = arr.getJSONObject(it)
                Scene(o.getString("text"), o.getString("search"))
            }
        }
    }

    /** Paso 3: clip vertical de Pexels. Devuelve su duración en segundos. */
    fun pexelsClip(key: String, query: String, minSec: Double, used: MutableSet<Long>, out: File): Double {
        val url = "https://api.pexels.com/videos/search?query=" + URLEncoder.encode(query, "UTF-8") +
            "&orientation=portrait&per_page=10"
        val vids = http.newCall(Request.Builder().url(url).header("Authorization", key).build()).execute().use { r ->
            val s = r.body!!.string()
            if (!r.isSuccessful) throw IllegalStateException("Pexels ${r.code}")
            JSONObject(s).getJSONArray("videos")
        }
        if (vids.length() == 0) throw IllegalStateException("Pexels no tiene clips para \"$query\"")
        var pick: JSONObject? = null
        for (i in 0 until vids.length()) {
            val v = vids.getJSONObject(i)
            if (v.getLong("id") in used) continue
            if (v.getDouble("duration") >= minSec) { pick = v; break }
            if (pick == null) pick = v
        }
        val v = pick ?: vids.getJSONObject(0)
        used += v.getLong("id")
        val files = v.getJSONArray("video_files")
        var best: JSONObject? = null
        for (i in 0 until files.length()) {
            val f = files.getJSONObject(i)
            if (f.optString("file_type") != "video/mp4") continue
            val w = f.optInt("width")
            if (w > 1080) continue
            if (best == null || w > best.optInt("width")) best = f
        }
        val link = (best ?: files.getJSONObject(0)).getString("link")
        http.newCall(Request.Builder().url(link).build()).execute().use { r ->
            if (!r.isSuccessful) throw IllegalStateException("Descarga de clip ${r.code}")
            out.outputStream().use { o -> r.body!!.byteStream().copyTo(o) }
        }
        return v.getDouble("duration")
    }

    fun durationMs(path: String): Long {
        val m = MediaMetadataRetriever()
        try {
            m.setDataSource(path)
            return m.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)!!.toLong()
        } finally { m.release() }
    }
}
