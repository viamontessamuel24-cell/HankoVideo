package com.bytebyte.hanko

import android.app.Application
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.util.UnstableApi
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.Locale

@UnstableApi
class MainVm(app: Application) : AndroidViewModel(app) {
    val prefs = Prefs(app)
    var status by mutableStateOf("")
    var busy by mutableStateOf(false)
    var result by mutableStateOf<File?>(null)
    var errorMsg by mutableStateOf<String?>(null)

    fun save() { result?.let { Composer.saveToGallery(getApplication(), it) } }

    fun generate(topic: String, lang: String) {
        if (busy) return
        viewModelScope.launch {
            busy = true; errorMsg = null; result = null
            val ctx = getApplication<Application>()
            val dir = File(ctx.cacheDir, "work").apply { deleteRecursively(); mkdirs() }
            val voice = Voice(ctx)
            try {
                if (prefs.llmKey.isBlank() || prefs.pexelsKey.isBlank())
                    throw IllegalStateException("Añade tus claves en Ajustes")
                status = "Escribiendo el guion…"
                val scenes = withContext(Dispatchers.IO) { Api.script(prefs, topic, lang) }

                status = "Generando la voz…"
                voice.init(Locale.forLanguageTag(lang))
                val voices = scenes.mapIndexed { i, s -> File(dir, "v$i.wav").also { voice.toFile(s.text, it) } }
                val voiceMs = voices.map { Api.durationMs(it.path) }

                status = "Buscando clips…"
                val used = mutableSetOf<Long>()
                val clipSec = mutableListOf<Double>()
                val clips = withContext(Dispatchers.IO) {
                    scenes.mapIndexed { i, s ->
                        File(dir, "c$i.mp4").also {
                            clipSec += Api.pexelsClip(prefs.pexelsKey, s.search, voiceMs[i] / 1000.0, used, it)
                        }
                    }
                }

                status = "Montando el vídeo…"
                val out = File(dir, "hanko.mp4")
                Composer.render(ctx, scenes, voices, voiceMs, clips, clipSec, out)
                result = out
            } catch (e: Exception) {
                errorMsg = e.message ?: e.toString()
            } finally {
                voice.shutdown(); busy = false
            }
        }
    }
}
