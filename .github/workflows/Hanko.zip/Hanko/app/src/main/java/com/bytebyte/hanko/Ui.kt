package com.bytebyte.hanko

import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.BlurredEdgeTreatment
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp

val Red = Color(0xFFC8102E)      // 朱色 shuiro, rojo del sello hanko
val Ink = Color(0xFF2A2326)

/** Fondo blanco con dos manchas rojas desenfocadas: es lo que el cristal "refracta". */
@Composable
fun GlassBackground(content: @Composable BoxScope.() -> Unit) {
    Box(
        Modifier.fillMaxSize()
            .background(Brush.verticalGradient(listOf(Color.White, Color(0xFFF4F2F3))))
    ) {
        Box(
            Modifier.align(Alignment.TopStart).offset((-90).dp, (-30).dp).size(280.dp)
                .blur(90.dp, BlurredEdgeTreatment.Unbounded).background(Red.copy(alpha = .34f), CircleShape)
        )
        Box(
            Modifier.align(Alignment.BottomEnd).offset(70.dp, 50.dp).size(300.dp)
                .blur(100.dp, BlurredEdgeTreatment.Unbounded).background(Red.copy(alpha = .22f), CircleShape)
        )
        content()
    }
}

/** Panel de cristal: blanco translúcido, borde con luz y sombra rojiza suave. */
@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(30.dp)
    Column(
        modifier
            .shadow(20.dp, shape, ambientColor = Red.copy(alpha = .15f), spotColor = Red.copy(alpha = .25f))
            .background(Brush.linearGradient(listOf(Color.White.copy(alpha = .78f), Color.White.copy(alpha = .36f))), shape)
            .border(
                1.dp,
                Brush.linearGradient(listOf(Color.White, Color.White.copy(alpha = .15f), Red.copy(alpha = .30f))),
                shape
            )
            .padding(20.dp),
        content = content
    )
}

@Composable
fun Pill(text: String, filled: Boolean, modifier: Modifier = Modifier, onClick: () -> Unit) {
    val shape = RoundedCornerShape(50)
    val look = if (filled) Modifier.background(Brush.verticalGradient(listOf(Color(0xFFE5384F), Red)), shape)
    else Modifier.background(Color.White.copy(alpha = .55f), shape).border(1.dp, Red.copy(alpha = .5f), shape)
    Box(
        modifier.clip(shape).then(look).clickable(onClick = onClick).padding(horizontal = 18.dp, vertical = 12.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = if (filled) Color.White else Red, fontWeight = FontWeight.SemiBold) }
}

@Composable
fun GlassField(value: String, onChange: (String) -> Unit, hint: String, secret: Boolean = false) {
    OutlinedTextField(
        value, onChange, Modifier.fillMaxWidth(),
        placeholder = { Text(hint) }, singleLine = true,
        shape = RoundedCornerShape(18.dp),
        visualTransformation = if (secret) PasswordVisualTransformation() else VisualTransformation.None,
        colors = OutlinedTextFieldDefaults.colors(
            focusedBorderColor = Red, unfocusedBorderColor = Color.White, cursorColor = Red,
            focusedContainerColor = Color.White.copy(alpha = .55f), unfocusedContainerColor = Color.White.copy(alpha = .40f)
        )
    )
}
