package com.bytebyte.hanko

import android.content.Context
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.suspendCancellableCoroutine
import java.io.File
import java.util.Locale
import java.util.UUID
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

/** Voz con el TextToSpeech del propio Android (sin servidores ni claves). */
class Voice(private val ctx: Context) {
    private var tts: TextToSpeech? = null

    suspend fun init(locale: Locale) = suspendCancellableCoroutine<Unit> { c ->
        tts = TextToSpeech(ctx) { status ->
            if (status == TextToSpeech.SUCCESS) {
                tts?.language = locale
                c.resume(Unit)
            } else c.resumeWithException(IllegalStateException("El motor de voz de Android no está disponible"))
        }
    }

    suspend fun toFile(text: String, out: File) = suspendCancellableCoroutine<Unit> { c ->
        tts!!.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { if (c.isActive) c.resume(Unit) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) {
                if (c.isActive) c.resumeWithException(IllegalStateException("Fallo al generar la voz"))
            }
        })
        tts!!.synthesizeToFile(text, Bundle(), out, UUID.randomUUID().toString())
    }

    fun shutdown() { tts?.shutdown() }
}
