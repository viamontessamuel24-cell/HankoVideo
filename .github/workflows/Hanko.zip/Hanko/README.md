# Hanko 判子

App Android nativa (Kotlin + Jetpack Compose) que crea vídeos cortos verticales con IA:
tema → guion (IA de texto) → voz (TextToSpeech de Android) → clips (Pexels) → vídeo con subtítulos (Media3 Transformer).

Inspirada en el flujo de [MoneyPrinterTurbo](https://github.com/harry0703/MoneyPrinterTurbo) (licencia MIT).
Es una reescritura independiente; si copias código o prompts de ese proyecto, incluye su aviso de copyright y el texto de su LICENSE.

## Compilar el APK
1. Sube esta carpeta a un repositorio de GitHub.
2. Pestaña **Actions** → "Build APK" (se ejecuta sola en cada push).
3. Al terminar, descarga el artefacto **Hanko-debug-apk**.

O abre la carpeta en Android Studio y pulsa Run.

## Configuración en la app
Ajustes → URL base, clave y modelo de una API compatible con OpenAI (OpenAI, DeepSeek, Gemini...) y tu clave de Pexels.
